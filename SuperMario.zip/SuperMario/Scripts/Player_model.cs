﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_model : MonoBehaviour {
    public Rigidbody2D rb2d;
    public float speed;
    public bool grounded;
    public float jumpForce;

    public GameObject spawnPoint;
    public GameObject bulletPrefab;
    public int direction;

    public int score;

    




}
