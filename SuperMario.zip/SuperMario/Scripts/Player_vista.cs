﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Player_vista : MonoBehaviour {

    public TextMesh scoreText;
     public int score = 0;
    public void Start() {
        scoreText = GameObject.Find("Score Text").GetComponent<TextMesh>();
    }



    public void Update() {
        //scoreText = "" + score;

    }

    public void Addscore(int nuevoValor) {
        score += nuevoValor;
    }
}
