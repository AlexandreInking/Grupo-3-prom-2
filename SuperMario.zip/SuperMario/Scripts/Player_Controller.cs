﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller : Player_model {



    

    void Start() {
        rb2d = GetComponent<Rigidbody2D>();
    }


    void Update()
    {
        Move();
        Jump();
        Shoot();
        
    }




    void Move() {
        float horizontal = Input.GetAxisRaw("Horizontal");
        rb2d.velocity = new Vector2(horizontal * speed, rb2d.velocity.y);

        if (horizontal > 0) {
            direction = 1;
        } else if (horizontal < 0) {
            direction = -1;
        }
        Vector3 Flip_personaje = transform.localScale;
        if (direction== -1) {
            Flip_personaje.x = 1;
        }
        if (direction == 1) {
            Flip_personaje.x = -1;
        }
        transform.localScale = Flip_personaje;
    }

    void Jump() {
        if (grounded && Input.GetKeyDown(KeyCode.Space)) {
            grounded = false;
            rb2d.AddForce(new Vector2(0, jumpForce));
        }
    }

    void Shoot() {
        if (Input.GetKeyDown(KeyCode.X)) {
            GameObject obj = Instantiate(bulletPrefab);
            obj.transform.position = spawnPoint.transform.position;
            obj.GetComponent<BulletController>().speed = direction * 10;
        }
    }


    void OnTriggerEnter2D(Collider2D collision) {
            if (collision.gameObject.CompareTag("Coin")) {
                score += collision.gameObject.GetComponent<CoinController>().score;
                Debug.Log("monedas" + score);
                Destroy(collision.gameObject);
            } 
            
        }

   

    void OnCollisionEnter2D(Collision2D collision) {
        if (collision.gameObject.CompareTag("Ground")) {
            grounded = true;
        }
    }

    void OnCollisionExit2D(Collision2D collision) {
        if (collision.gameObject.CompareTag("Ground")) {
            grounded = false;
        }
    }







}
