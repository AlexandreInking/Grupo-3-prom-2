﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D rb2d;
    public float speed;
    public bool grounded;
    public float jumpForce;

    public GameObject spawnPoint;
    public GameObject bulletPrefab;
    public int direction;

    public int score;

    public GameObject switcher;

    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        Jump();
        Shoot();
        Interact();
    }

    void Move()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");
        rb2d.velocity = new Vector2(horizontal*speed, rb2d.velocity.y);

        if (horizontal>0)
        {
            direction = 1;
        }
        else if(horizontal<0)
        {
            direction = -1;
        }
    }

    void Jump()
    {
        if(grounded && Input.GetKeyDown(KeyCode.Space))
        {
            grounded = false;
            rb2d.AddForce(new Vector2(0, jumpForce));
        }
    }

    void Shoot()
    {
        if(Input.GetKeyDown(KeyCode.X))
        {
            GameObject obj = Instantiate(bulletPrefab);
            obj.transform.position = spawnPoint.transform.position;
            obj.GetComponent<BulletController>().speed = direction * 10;
        }
    }

    void Interact()
    {
        if(switcher != null && switcher.GetComponent<SwitchController>().wall != null && Input.GetKeyDown(KeyCode.E))
        {
            //Destroy(switcher.transform.parent.gameObject);
            Destroy(switcher.GetComponent<SwitchController>().wall);
            switcher = null;
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Ground"))
        {
            grounded = true;
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            grounded = false;
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Coin"))
        {
            score += collision.gameObject.GetComponent<CoinController>().score;
            Destroy(collision.gameObject);
        }
        else if(collision.gameObject.CompareTag("Switch"))
        {
            switcher = collision.gameObject;
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Switch"))
        {
            switcher = null;
        }
    }
}
