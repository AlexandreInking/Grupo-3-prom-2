﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    public Rigidbody2D rb;
    public float speed;

    public GameObject spawnPoint;
    public GameObject bulletPrefab;
    public GameObject bulletPrefab2;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Move();
        Shoot();
    }

    void Move()
    {
        float vertical = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");

        rb.velocity = new Vector2(horizontal * speed, vertical * speed);
    }

    void Shoot()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            GameObject temporalBullet = Instantiate(bulletPrefab);
            temporalBullet.transform.position = spawnPoint.transform.position;
            if (transform.localScale.x > 0)
            {
                temporalBullet.GetComponent<BulletScript>().speed = 10;
            }
            else
            {
                temporalBullet.GetComponent<SpriteRenderer>().flipX = true;
                temporalBullet.GetComponent<BulletScript>().speed = -10f;
            }
        }

        if (Input.GetKeyDown(KeyCode.X))
        {
            GameObject temporalBullet = Instantiate(bulletPrefab2);
            temporalBullet.transform.position = spawnPoint.transform.position;
            if (transform.localScale.x > 0)
            {
                temporalBullet.GetComponent<BulletScript>().speed = 10;
            }
            else
            {
                temporalBullet.GetComponent<SpriteRenderer>().flipX = true;
                temporalBullet.GetComponent<BulletScript>().speed = -10f;
            }
        }
    }
}
