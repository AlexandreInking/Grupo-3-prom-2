﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerControlerScript : MonoBehaviour
{
    public GameObject EnemySpawnerPoint;
    public GameObject EnemySpawnerPoint2;
    public GameObject EnemySpawnerPoint3;

    public GameObject EnemyPrefab;
    public GameObject EnemyPrefab2;
    public GameObject EnemyPrefab3;

    public float timer;
    public float createTimer;
    public float maxTimer;
    public float minTimer;


    // Start is called before the first frame update
    void Start()
    {
        createTimer = Random.Range(minTimer, maxTimer);
    }

    // Update is called once per frame
    void Update()
    {
        Spawn();
    }

    void Spawn()
    {
        //1
        timer = timer + Time.deltaTime;
        if (timer >= 8)
        {
            GameObject temporalEnemy = Instantiate(EnemyPrefab);
            temporalEnemy.transform.position = EnemySpawnerPoint.transform.position;

            timer = 0;
        }
        //2
        timer = timer + Time.deltaTime;
        if (timer >= 8)
        {
            GameObject temporalEnemy = Instantiate(EnemyPrefab2);
            temporalEnemy.transform.position = EnemySpawnerPoint2.transform.position;

            timer = 0;
        }
        //3
        timer = timer + Time.deltaTime;
        if (timer >= 8)
        {
            GameObject temporalEnemy = Instantiate(EnemyPrefab3);
            temporalEnemy.transform.position = EnemySpawnerPoint3.transform.position;

            timer = 0;
        }

    }

}
